<?php

namespace App\Scheduler\Message;

class ArchivLog
{

}