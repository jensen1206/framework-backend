<?php

namespace App\Scheduler\Message;

use App\Scheduler\Message\ArchivLog;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler]
class ArchivLogHandler
{
    public function __construct(
        private readonly KernelInterface $kernel,
    )
    {
    }

    public function __invoke(ArchivLog $message): void
    {
        $path = $this->kernel->getProjectDir() . '/var/log/cron_test.log';

        file_put_contents($path, date('Y-m-d H:i:s') . "\n", FILE_APPEND);
    }
}