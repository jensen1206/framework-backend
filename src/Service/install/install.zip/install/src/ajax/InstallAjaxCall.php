<?php

namespace App\ajax;

use Exception;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Yaml\Yaml;

class InstallAjaxCall
{
    protected object $responseJson;
    protected Request $data;

    public function __construct(
        private readonly string $installConf,
        private readonly string $projectDir
    )
    {
    }

    /**
     * @throws Exception
     */
    public function ajaxInstallSettings(Request $request)
    {
        $this->data = $request;
        $this->responseJson = (object)['status' => false, 'msg' => date('H:i:s'), 'type' => $request->get('method')];
        if (!method_exists($this, $request->get('method'))) {
            throw new Exception("Method not found!#Not Found");
        }

        return call_user_func_array(self::class . '::' . $request->get('method'), []);
    }

    private function composer_install(): object
    {
        $conf = Yaml::parseFile($this->installConf);
        $filesystem = new Filesystem();
        $archivDir = $conf['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
        if (!$filesystem->exists($archivDir . 'composer.phar') && !$conf['config']['export_vendor'] && !$filesystem->exists($archivDir . 'vendor')) {
            if (!copy('https://getcomposer.org/download/latest-stable/composer.phar', $archivDir . 'composer.phar')) {
                $this->responseJson->msg = 'composer.phar kann nicht erstellt werden. (err-' . __LINE__ . ')';
                return $this->responseJson;
            }
            $filesystem->chmod($archivDir . 'composer.phar', 0755);
        }
        $this->responseJson->msg = 'composer.phar kann nicht erstellt werden. (err-' . __LINE__ . ')';
        // dd($conf, $archivDir);
        if (!$filesystem->exists($archivDir . 'vendor')) {
            $log = $archivDir . 'install.log';
            $filesystem->remove($log);
            $phpData = $conf['config']['env']['PHP_VERSION_DATA'];
            $cmd = sprintf('%s %scomposer.phar install --working-dir="%s" > "%s" 2>&1', $phpData, $archivDir, $archivDir, $log);
            exec($cmd);
        }
        sleep(2);
        $this->responseJson->status = true;
        return $this->responseJson;
    }

    private function get_install_log(): object
    {
        $last = filter_var($this->data->get('last'), FILTER_VALIDATE_INT);
        $this->responseJson->last = $last;
        $this->responseJson->status = true;

        $t = 'Beware: calling $zip->addFile() on a file that doesnt exist will succeed and return TRUE, delaying the failure until you make the final $zip->close() call, which will return FALSE and potentially leave you scratching your head.';
        $this->responseJson->log = $t;
        return $this->responseJson;

    }

    private function activate_app(): object
    {
        $conf = Yaml::parseFile($this->installConf);
        $filesystem = new Filesystem();
        $archivDir = $conf['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
        $filesystem->remove($archivDir . 'install.log');
        $filesystem->remove($archivDir . 'install.json');


        $this->responseJson->ref = $conf['config']['env']['SITE_BASE_URL'];

        $envSrc = $this->projectDir . DIRECTORY_SEPARATOR . '.env';
        $envDest = $archivDir . '.env';
        if(!$filesystem->exists($envSrc) || !$filesystem->exists($envDest)) {
            $this->responseJson->msg = 'Das Archiv konnte nicht in das Zielverzeichnis kopiert werden.';
            return $this->responseJson;
        }
        try {
            $filesystem->copy($envSrc, $envDest);
        } catch (IOExceptionInterface $e) {
            $this->responseJson->msg = 'Das Archiv konnte nicht in das Zielverzeichnis kopiert werden.';
            return $this->responseJson;
        }

        $dest = $conf['install_dir'];
        $isPublicDir = false;
        if(str_ends_with($dest, 'public')) {
            $isPublicDir = true;
            $dest = dirname($dest);
        }

        try {
            $filesystem->mirror( $archivDir, $dest . DIRECTORY_SEPARATOR);
        } catch (IOExceptionInterface $e) {
            $this->responseJson->msg = 'Das Archiv konnte nicht in das Zielverzeichnis kopiert werden.';
            return $this->responseJson;
        }
        if(!$isPublicDir) {
            try {
                $filesystem->remove($archivDir);
            } catch (IOExceptionInterface $e) {
                $this->responseJson->msg = 'Das Archiv konnte nicht gelöscht werden.';
                return $this->responseJson;
            }
        }
      /*  try {
            $filesystem->remove($this->projectDir);
        } catch (IOExceptionInterface $e) {
            $this->responseJson->msg = 'Der Installationsordner konnte nicht gelöscht werden.';
            return $this->responseJson;
        }*/

        $this->responseJson->status = true;
        return $this->responseJson;
    }
}