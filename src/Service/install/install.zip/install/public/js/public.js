const windowPublicReady = new Promise(resolve => {
    if (document.readyState === 'complete') {
        resolve('ready');
    } else {
        window.addEventListener('load', resolve);
    }
});


windowPublicReady.then((resolve) => {

    let logWrapper = document.getElementById('composer-log');
    let installLog = document.getElementById('installLog');
    let logOutput = document.getElementById('output-console');
    let spinner = `<div style="width: 3rem; height: 3rem;" class="spinner-border  text-success" role="status"><span class="visually-hidden">Loading...</span></div>`;
    let source;
    // PUBLIC  Functions
    let toggle = document.querySelector('.toggle-button');
    if (toggle) {
        toggle.addEventListener("click", toggleButton);
    }

    function xhr_handle(data, callback) {
        let xhr = new XMLHttpRequest();
        let formData = new FormData();
        xhr.open('POST', installSettings.ajax_url, true);
        for (let [name, value] of Object.entries(data)) {
            formData.append(name, value);
        }
        xhr.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                if (typeof callback === 'function') {
                    xhr.addEventListener("load", callback);
                    return false;
                }
            }
        }
        formData.append('token', installSettings.token);
        formData.append('_handle', installSettings.handle);
        xhr.send(formData);
    }


    function toggleButton() {
        if (toggle.classList.contains('active')) {
            toggle.classList.remove('active')
        } else {
            toggle.classList.add('active')
        }
    }

    let installFinale = document.getElementById('install-finale');
    if (installFinale) {
        installFinale.insertAdjacentHTML('afterbegin', spinner);
        let formData = {
            'method': 'activate_app'
        }
        xhr_handle(formData, callback_composer_install)
    }
    let actionBtn = document.querySelectorAll(".action-btn");
    if (actionBtn) {
        let btnNodes = Array.prototype.slice.call(actionBtn, 0);
        let formData;
        btnNodes.forEach(function (btnNodes) {
            btnNodes.addEventListener("click", function (e) {
                let type = this.getAttribute('data-type')
                switch (type) {
                    case 'composer_install':
                        formData = {
                            'method': type,
                        }
                        logOutput.innerHTML = '';
                        let html = `<li class="my-2">--- Composer Install ---</li>`;
                        logOutput.insertAdjacentHTML('beforeend', html)
                        const bsCollapse = new bootstrap.Collapse('#console-log-wrapper', {
                            toggle: false,
                            parent: '#installLog'
                        })
                        bsCollapse.show();
                        eventSourceInit()

                        break;
                }
                if (formData) {
                    xhr_handle(formData, callback_composer_install)
                }
            })
        })
    }

    function callback_composer_install() {
        let data = JSON.parse(this.responseText);
        let formData;
        switch (data.type) {
            case 'composer_install':
                //clearInterval(logInterval);
                source.close();
                if (data.status) {
                    formData = {
                        'method': 'activate_app'
                    }
                    xhr_handle(formData, callback_composer_install)
                    logWrapper.remove()
                    document.getElementById('console-log-wrapper').remove()
                    //let spinner = `<div style="width: 3rem; height: 3rem;" class="spinner-border  text-primary" role="status"><span class="visually-hidden">Loading...</span></div>`;
                    installLog.insertAdjacentHTML('afterbegin', spinner);
                } else {
                    installLog.innerHTML = '';
                    let alert = `<div class="alert alert-danger d-block start-0 end-0 m-4 top-0 position-absolute" role="alert"><h4 class="alert-heading">Installation fehlgeschlagen</h4> <p>${data.msg}</p></div>`;
                    installLog.insertAdjacentHTML('afterbegin', alert)
                }
                break;
            case 'activate_app':
                if (data.status) {
                    location.href = data.ref
                } else {
                    document.getElementById('install-finale').remove()
                    let alert = `<div class="alert alert-danger d-block start-0 end-0 m-4 top-0 position-absolute" role="alert"><h4 class="alert-heading">Installation fehlgeschlagen</h4> <p>${data.msg}</p></div>`;
                    installLog.insertAdjacentHTML('afterbegin', alert)

                }
                break;
        }
    }

    function scrollToBottom() {
        logOutput.scrollIntoView({behavior: 'smooth', block: 'end'});
    }

    function eventSourceInit() {
        if (typeof (EventSource) !== "undefined") {
            let evUrl = `${installSettings.event_url}`;
            source = new EventSource(evUrl);
            source.addEventListener('composerLog', composerLog, true)
            let circle = document.querySelector('.load-phar-circle');

            function composerLog(event) {
                const data = JSON.parse(event.data);
                if (data.status) {
                    if (data.log && circle) {
                        circle.remove()
                    }
                    if (data.lines.length) {
                        data.lines.map((v, i) => {
                            let html = `<li class="mb-2">${v}</li>`;
                            logOutput.insertAdjacentHTML('beforeend', html)
                            scrollToBottom()
                        })
                    }
                }
            }

            source.addEventListener('errorLog', function (event) {
                const data = JSON.parse(event.data);


            });
        }
    }
})