<?php

namespace App\Controller;

use App\ajax\InstallAjaxCall;
use App\InstallHelper\Helper;
use App\Service\SqlScriptParser;
use Defuse\Crypto\Exception\EnvironmentIsBrokenException;
use Doctrine\DBAL\DriverManager;
use Doctrine\DBAL\Tools\DsnParser;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use PDO;
use Psr\Container\ContainerExceptionInterface;
use Psr\Container\NotFoundExceptionInterface;
use stdClass;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Console\Exception\RunCommandFailedException;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Path;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Messenger\Exception\HandlerFailedException;
use Symfony\Component\Process\PhpExecutableFinder;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Yaml\Yaml;
use Defuse\Crypto\Key;
use Symfony\Component\Console\Messenger\RunCommandMessage;
use Symfony\Component\Messenger\MessageBusInterface;
use Doctrine\DBAL\Exception\ConnectionException;
use ZipArchive;

class MainController extends AbstractController
{
    private string $phpDataVersion;

    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly MessageBusInterface    $bus,
        private readonly Helper                 $helper,
        private readonly InstallAjaxCall        $ajaxCall,

    )
    {


    }

    #[Route('/', name: 'app_main')]
    public function index(Request $request): Response
    {

        /*$executableFinder = new PhpExecutableFinder();
        $php = $executableFinder->find(false);
        $php = false === $php ? null : array_merge([$php], $executableFinder->findArguments());*/

        if (version_compare(PHP_VERSION, $request->server->get('PHP_MIN'), '<')) {
            $this->addFlash('install_error', sprintf('Installation nicht möglich. Ihre PHP-Version %s ist nicht kompatibel. Es wird eine PHP-Version %s benötigt.', PHP_VERSION, $request->server->get('PHP_MIN')));
            return $this->render('main/index.html.twig', [
                'title' => 'Datenbank Settings',
            ]);
        }
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/index.html.twig', [
                'title' => 'Datenbank Settings',
                'data' => []
            ]);
        }

        $submittedToken = $request->getPayload()->get('_csrf_token');
        $btnPressed = $request->get('install_app') !== null;
        if ($request->getMethod() === 'POST' && $btnPressed && $this->isCsrfTokenValid('install_form', $submittedToken)) {
            $filesystem = new Filesystem();
            $input = $request->request;
            $db_name = $this->helper->trim_string(filter_var($input->get('db_name'), FILTER_UNSAFE_RAW));
            $db_user = $this->helper->trim_string(filter_var($input->get('db_user'), FILTER_UNSAFE_RAW));
            $db_pw = filter_var($input->get('db_pw'), FILTER_UNSAFE_RAW);
            $db_host = $this->helper->trim_string(filter_var($input->get('db_host'), FILTER_UNSAFE_RAW));
            $db_charset = $this->helper->trim_string(filter_var($input->get('db_charset'), FILTER_UNSAFE_RAW));
            $db_server = $this->helper->trim_string(filter_var($input->get('db_server'), FILTER_UNSAFE_RAW));
            if (!$db_name || !$db_user || !$db_pw || !$db_host) {
                $this->addFlash('input_error', 'bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/index.html.twig', [
                    'title' => 'Datenbank Settings',
                    'data' => $conf->record
                ]);
            }
            if (!$db_charset) {
                $db_charset = 'utf8mb4';
            }
            if (!$db_server) {
                $db_server = 'mariadb-10.3.36';
            }
            $dsn = sprintf('mysql://%s:%s@%s:3306/%s?serverVersion=%s&charset=%s', $db_user, $db_pw, $db_host, $db_name, $db_server, $db_charset);
            $envJson = $conf->record;

            $envJsonDb = $envJson['database'];
            $json = $envJson['config']['env'];

            $envJsonDb['user'] = $db_user;
            $envJsonDb['password'] = $db_pw;
            $envJsonDb['host'] = $db_host;
            $envJsonDb['dbname'] = $db_name;
            $envJsonDb['charset'] = $db_charset;
            $envJsonDb['serverVersion'] = $db_server;
            $json['DATABASE_URL'] = $dsn;

            $envJson['database'] = $envJsonDb;
            $envJson['config']['env'] = $json;

            $yaml = Yaml::dump($envJson, 6);

            file_put_contents($this->getParameter('installConf'), $yaml);
            $env = $this->getParameter('projectDir') . DIRECTORY_SEPARATOR . '.env';
            if (!$filesystem->exists($env)) {
                $this->addFlash('install_error', 'Environment-File nicht gefunden. (Err - ' . __LINE__ . ')');
                return $this->render('main/index.html.twig', [
                    'title' => 'Datenbank Settings',
                    'data' => []
                ]);
            }

            $files = file($env);
            $envFileArr = [];
            foreach ($files as $file) {
                $searchFile = $this->helper->pregWhitespace($file);
                if (str_starts_with($searchFile, 'DATABASE_URL')) {
                    $addFile = sprintf('DATABASE_URL="%s"', $json['DATABASE_URL']) . "\r\n";
                } else if (str_starts_with($searchFile, 'SITE_BASE_URL')) {
                    $addFile = sprintf('SITE_BASE_URL="%s"', $json['SITE_BASE_URL']) . "\r\n";
                } else if (str_starts_with($searchFile, 'APP_SITE_NAME')) {
                    $addFile = sprintf('APP_SITE_NAME="%s"', $json['APP_SITE_NAME']) . "\r\n";
                } else if (str_starts_with($searchFile, 'MAILER_DSN')) {
                    $addFile = sprintf('MAILER_DSN=%s', $json['MAILER_DSN']) . "\r\n";
                } else if (str_starts_with($searchFile, 'APP_SECRET')) {
                    $addFile = sprintf('APP_SECRET=%s', $json['APP_SECRET']) . "\r\n";
                } else if (str_starts_with($searchFile, 'APP_CATEGORY_NAME')) {
                    $addFile = sprintf('APP_CATEGORY_NAME="%s"', $json['APP_CATEGORY_NAME']) . "\r\n";
                } else if (str_starts_with($searchFile, 'APP_POST_CATEGORY_NAME')) {
                    $addFile = sprintf('APP_POST_CATEGORY_NAME="%s"', $json['APP_POST_CATEGORY_NAME']) . "\r\n";
                } else if (str_starts_with($searchFile, 'PHP_VERSION_DATA')) {
                    $addFile = sprintf('PHP_VERSION_DATA="%s"', $json['PHP_VERSION_DATA']) . "\r\n";
                } else {
                    $addFile = $file;
                }
                $envFileArr[] = $addFile;
            }

            file_put_contents($env, '');
            foreach ($envFileArr as $val) {
                file_put_contents($env, $val, FILE_APPEND | LOCK_EX);
            }

            return $this->redirect($this->generateUrl('app_settings'));

        }

        return $this->render('main/index.html.twig', [
            'title' => 'Datenbank Settings',
            'data' => $conf->record
        ]);
    }

    /**
     * @throws \Doctrine\DBAL\Exception
     */
    #[Route('/settings', name: 'app_settings')]
    public function settings(Request $request): Response
    {
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/step-two.html.twig', [
                'title' => 'Datenbank Settings',
                'data' => []
            ]);
        }

        if (!$this->helper->database_is_installed()) {
            $this->addFlash('input_error', 'Es konnte <b>keine Verbindung</b> zu Ihrer Datenbank hergestellt werden.');
            return $this->redirect($this->generateUrl('app_main'));
        }
        //$this->em->getMetadataFactory()->getAllMetadata()
        $ref = basename($request->headers->get('referer'));

        if ($request->getMethod() === 'GET' && $ref != 'public') {
            return $this->redirect($this->generateUrl('app_main'));
        }
        $submittedToken = $request->getPayload()->get('_csrf_token');
        if ($request->getMethod() === 'POST' && $this->isCsrfTokenValid('install_two_app', $submittedToken)) {
            $filesystem = new Filesystem();
            $input = $request->request;
            $install_path = $this->helper->trim_string(filter_var($input->get('install_path'), FILTER_UNSAFE_RAW));
            $install_url = $this->helper->trim_string(filter_var($input->get('install_url'), FILTER_VALIDATE_URL));
            $email_user = $this->helper->trim_string(filter_var($input->get('email_user'), FILTER_UNSAFE_RAW));
            $email_host = $this->helper->trim_string(filter_var($input->get('email_host'), FILTER_UNSAFE_RAW));
            $email_pw = $this->helper->trim_string(filter_var($input->get('email_pw'), FILTER_UNSAFE_RAW));
            $email_port = $this->helper->trim_string(filter_var($input->get('email_port'), FILTER_VALIDATE_INT));
            $jsonConf = $conf->record;

            if (!$install_path || !$install_url) {
                $this->addFlash('input_error', 'bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/step-two.html.twig', [
                    'title' => 'Installation Einstellungen',
                    'data' => $conf->record
                ]);
            }

            if (str_ends_with($install_url, '/')) {
                $install_url = preg_replace('%/$%', '', $install_url);
            }
            if (str_ends_with($install_path, '/')) {
                $install_path = preg_replace('%/$%', '', $install_path);
            }
            if (!@is_dir($install_path)) {
                $this->addFlash('input_error', 'Das Installationsverzeichnis ist ungültig. Bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/step-two.html.twig', [
                    'title' => 'Installation Einstellungen',
                    'data' => $conf->record
                ]);
            }
            $pathEx = explode(DIRECTORY_SEPARATOR, $install_path);
            if (!in_array(basename($request->server->get('DOCUMENT_ROOT')), $pathEx)) {
                $this->addFlash('input_error', 'Das Installationsverzeichnis ist ungültig.');
                return $this->render('main/step-two.html.twig', [
                    'title' => 'Installation Einstellungen',
                    'data' => $conf->record
                ]);
            }


            $jsonConf['install_dir'] = $install_path;
            $jsonConf['config']['env']['SITE_BASE_URL'] = $install_url;

            if ($email_user) {
                $jsonConf['email_dsn']['username'] = $email_user;
            }
            if ($email_host) {
                $jsonConf['email_dsn']['host'] = $email_host;
            }
            if ($email_pw) {
                $jsonConf['email_dsn']['pw'] = $email_pw;
            }
            if ($email_port) {
                $jsonConf['email_dsn']['port'] = $email_port;
            }

            $dsn = sprintf('smtp://%s:%s@%s:%d', $jsonConf['email_dsn']['username'], $jsonConf['email_dsn']['pw'], $jsonConf['email_dsn']['host'], $jsonConf['email_dsn']['port']);
            $jsonConf['config']['env']['MAILER_DSN'] = $dsn;


            $yaml = Yaml::dump($jsonConf, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);


            $sqlFile = $this->getParameter('archivDir') . 'database.sql';
            if (!$filesystem->exists($sqlFile)) {
                $this->addFlash('input_error', 'Datenbank SQL-File nicht gefunden.');
                return $this->redirect($this->generateUrl('app_main'));
            }
            $conn = $this->em->getConnection();
            $sql = "SELECT app FROM system_settings WHERE designation = ?";

            try {
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(1, "system");
                $resultSet = $stmt->executeQuery();
                $result = $resultSet->fetchOne();

            } catch (Exception $e) {

                $dir = $this->getParameter('projectDir') . DIRECTORY_SEPARATOR;
                //$cmd = sprintf('%s %sbin/console dbal:run-sql "$(cat %s)"', $phpData, $dir, $sqlFile);
               // $fsq = file_get_contents($sqlFile);
               /* $cmd2 = sprintf('dbal:run-sql "%s"', $fsq);
                try {
                    $this->bus->dispatch(new RunCommandMessage($cmd2));
                } catch (RunCommandFailedException $e) {
                    $this->addFlash('input_error', 'Datenbank konnte nicht erstellt werden: ') . $e->getMessage();
                    return $this->redirect($this->generateUrl('app_main'));
                }*/

                $db = $this->em->getConnection()->getNativeConnection();
                $insertSql = trim(file_get_contents($sqlFile));
                if($insertSql) {
                    $db->beginTransaction();
                    $count = 0;
                    try{
                        $querySet = $db->prepare($insertSql);
                        $querySet->execute();
                        while($querySet->nextRowSet()){
                            ++$count;
                        }
                    }catch(Exception $e){
                        $db->rollBack();
                        throw $e;
                    }
                }
            }

            try {
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(1, "system");
                $resultSet = $stmt->executeQuery();
                $result = $resultSet->fetchOne();
                if (!$result) {
                    $this->addFlash('input_error', 'Datenbank konnte nicht erstellt werden. (err-' . __LINE__ . ')');
                    return $this->redirect($this->generateUrl('app_main'));
                }

            } catch (Exception $e) {
                $this->addFlash('input_error', $e->getMessage());
                return $this->redirect($this->generateUrl('app_main'));
            }
            $result = json_decode($result, true);

            $installData = [
                'version' => $result['version'],
                'title' => $result['site_name'],
                'admin' => $result['admin_email']
            ];

            $jsonConf['install_data'] = $installData;
            $yaml = Yaml::dump($jsonConf, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);

            return $this->redirect($this->generateUrl('app_install'));
        }

        return $this->render('main/step-two.html.twig', [
            'title' => 'Installation Einstellungen',
            'data' => $conf->record
        ]);
    }

    #[Route('/app-install', name: 'app_install')]
    public function app_install(Request $request): Response
    {
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/install.html.twig', [
                'title' => 'Archiv Installieren',
                'data' => []
            ]);
        }
        $conf = $conf->record;
        $ref = basename($request->headers->get('referer'));

        if ($request->getMethod() === 'GET' && $ref != 'settings') {
            return $this->redirect($this->generateUrl('app_main'));
        }

        $submittedToken = $request->getPayload()->get('_csrf_token');
        if ($request->getMethod() === 'POST' && $this->isCsrfTokenValid('app_install', $submittedToken)) {
            $filesystem = new Filesystem();
            if (!$filesystem->exists($conf['install_dir'])) {
                $this->addFlash('install_error', 'Installation Verzeichnis nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }

            $archiveDir = $this->getParameter('archivDir');
            $zipFile = $archiveDir . 'archiv.zip';
            if (!$filesystem->exists($zipFile)) {
                $this->addFlash('install_error', 'Installation Zip-Archiv nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }

            $archivDir = $conf['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
            if (!$filesystem->exists($archivDir)) {
                $zip = new ZipArchive();
                if ($zip->open($zipFile) === TRUE) {
                    $zip->extractTo($conf['install_dir'] . DIRECTORY_SEPARATOR);
                    $zip->close();
                } else {
                    $this->addFlash('install_error', 'Fehler beim entpacken der Archiv Datei!');
                    return $this->redirect($this->generateUrl('app_main'));
                }
            }

            $archivConf = $archivDir . '.env';
            if (!$filesystem->exists($archivConf)) {
                $this->addFlash('install_error', 'Archiv Konfiguration nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }

            //file_put_contents($archivConf, '');
            return $this->redirect($this->generateUrl('app_install_vendor'));
        }

        return $this->render('main/install.html.twig', [
            'title' => 'Archiv Installieren',
            'data' => $conf
        ]);
    }

    #[Route('/vendor-install', name: 'app_install_vendor')]
    public function app_install_vendor(Request $request): Response
    {
        $ref = basename($request->headers->get('referer'));
        if ($request->getMethod() === 'GET' && $ref != 'app-install') {
            return $this->redirect($this->generateUrl('app_main'));
        }
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/install.html.twig', [
                'title' => 'Archiv Installieren',
                'data' => []
            ]);
        }
        $conf = $conf->record;
        $submittedToken = $request->getPayload()->get('_csrf_token');
        if ($request->getMethod() === 'POST' && $this->isCsrfTokenValid('composer_install', $submittedToken)) {

            $filesystem = new Filesystem();
            $archivDir = $conf['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
            // if(!$conf['config']['export_vendor'])
            if (!$filesystem->exists($archivDir . 'composer.phar') && !$conf['config']['export_vendor'] && !$filesystem->exists($archivDir . 'vendor')) {
                if (!copy('https://getcomposer.org/download/latest-stable/composer.phar', $archivDir . 'composer.phar')) {
                    $this->addFlash('install_error', 'composer.phar kann nicht erstellt werden. (err-' . __LINE__ . ')');
                    return $this->render('main/install.html.twig', [
                        'title' => 'Archiv Installieren',
                        'data' => []
                    ]);
                }
                $filesystem->chmod($archivDir . 'composer.phar', 0755);

            }

            if (!$filesystem->exists($archivDir . 'vendor')) {
                $log = $archivDir . 'install.log';
                $filesystem->remove($log);
                $phpData = $conf['config']['env']['PHP_VERSION_DATA'];
                $cmd = sprintf('%s %scomposer.phar install --working-dir="%s" > "%s" 2>&1', $phpData, $archivDir, $archivDir, $log);
                exec($cmd);
            }

            if ($filesystem->exists($archivDir . 'vendor')) {
                return $this->render('main/bibliotheken-installieren.html.twig', [
                    'title' => 'Installieren',
                    'data' => $conf,
                    'installed' => true,
                ]);
            }
        }
        //
        return $this->render('main/bibliotheken-installieren.html.twig', [
            'title' => 'Bibliotheken Installieren',
            'data' => $conf,
            'installed' => false,
        ]);
    }

    public function get_archive_data($request): object
    {

        $return = new stdClass();
        $filesystem = new Filesystem();
        $return->status = false;

        if (!$filesystem->exists($this->getParameter('installConf'))) {

            $installZip = $this->getParameter('archivDir') . 'archiv.zip';
            $installJson = $this->getParameter('archivDir') . 'config.json';
            $installSql = $this->getParameter('archivDir') . 'database.sql';
            $installJson = json_decode(file_get_contents($installJson), true);

            if (!$installJson) {
                $return->msg = 'Json File kann nicht gefunden werden.';
                return $return;
            }

            if (!$installSql) {
                $return->msg = 'SQL File kann nicht gefunden werden.';
                return $return;
            }
            if (!$installZip) {
                $return->msg = 'Archiv File kann nicht gefunden werden.';
                return $return;
            }

            if (isset($installJson['file_size']) && $installJson['file_size']) {
                $zipSize = $this->helper->fileSizeConvert((float)$installJson['file_size']);
            } else {
                $zipSize = $this->helper->fileSizeConvert($this->helper->get_file_size($installZip));
            }
            if (isset($installJson['sql_size']) && $installJson['sql_size']) {
                $sqlSize = $this->helper->fileSizeConvert((float)$installJson['sql_size']);
            } else {
                $sqlSize = $this->helper->fileSizeConvert($this->helper->get_file_size($installSql));
            }
            if (isset($installJson['created_date']) && $installJson['created_date']) {
                $created_date = date('d.m.Y H:i:s', $installJson['created_date']);
            } else {
                $created_date = date('d.m.Y H:i:s');
            }

            //$re = '~\d.*~';
            //preg_match($re, PHP_DATADIR, $matches);
            //$matches ? $v = $matches[0] : $v = '';
            //$phpDataVersion = 'php' . $v;
            $phpDataVersion = $this->helper->get_php_version();
            $conn = $this->em->getConnection('doctrine');
            $dsn = $conn->getParams();

            $installUrl = $request->getSchemeAndHttpHost();
            $appSecret = md5(time());

            try {
                $key = Key::createNewRandomKey();
                $key = $key->saveToAsciiSafeString();
            } catch (EnvironmentIsBrokenException $e) {
                $return->msg = $e->getMessage();
                return $return;
            }

            $regDsn = '%(.+?)://(.*):(.+)@(.+)?:(\d{1,5})%';
            preg_match($regDsn, $installJson['env']['MAILER_DSN'], $matches);
            $email = [
                'type' => $matches[1] ?? null,
                'username' => $matches[2] ?? null,
                'pw' => $matches[3] ?? null,
                'host' => $matches[4] ?? null,
                'port' => $matches[5] ?? null
            ];

            $platform = sprintf('%s %s', php_uname('s'), php_uname('r'));
            $installJson['env']['PHP_VERSION_DATA'] = $phpDataVersion;
            $installJson['env']['APP_SECRET'] = $appSecret;
            $installJson['env']['SITE_BASE_URL'] = $installUrl;

            $config = [
                'install_dir' => dirname($this->getParameter('projectDir')),
                'archiv_size' => $zipSize,
                'platform' => $platform,
                'php_version' => PHP_VERSION,
                'sql_size' => $sqlSize,
                'defuse_key' => $key,
                'created' => $created_date,
                'database' => $dsn,
                'email_dsn' => $email,
                'config' => $installJson,
            ];

            $yaml = Yaml::dump($config, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);
            $return->status = true;
            $return->record = $config;
            return $return;
        }

        $config = Yaml::parseFile($this->getParameter('installConf'));
        $return->status = true;
        $return->record = $config;
        return $return;

    }

    /**
     * @throws ContainerExceptionInterface
     * @throws NotFoundExceptionInterface
     */
    #[Route('/install-settings.js', name: 'javascript_install_settings')]
    public function install_settings_settings(): Response
    {
        $csrf = $this->container->get('security.csrf.token_manager');
        $token = $csrf->getToken('install_settings_token');
        $settings = [
            'token' => $token->getValue(),
            'ajax_url' => $this->generateUrl('install_ajax'),
            'event_url' => $this->generateUrl('composer_event'),
            'handle' => 'ajaxInstallSettings',
        ];

        $systemJs = $this->renderView(
            'main/installSettings.js.twig',
            array(
                'json' => json_encode($settings)
            )
        );
        return new Response($systemJs, 200,
            array('Content-Type' => 'text/javascript')
        );
    }

    #[Route('/install-ajax', name: 'install_ajax', methods: ['POST'])]
    public function public_ajax_class(Request $request): JsonResponse
    {
        $token = $request->request->get('token');
        $method = $request->request->get('method');
        $handle = $request->request->get('_handle');

        if (!$this->isCsrfTokenValid('install_settings_token', $token) || !$method || !$handle) {
            return new JsonResponse(
                (object)[],
                403);
        }

        return new JsonResponse(
            $this->ajaxCall->$handle($request),
            200);
    }
}
