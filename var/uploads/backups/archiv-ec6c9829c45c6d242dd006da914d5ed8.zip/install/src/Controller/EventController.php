<?php

namespace App\Controller;

use Exception;
use stdClass;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Yaml\Yaml;

class EventController extends AbstractController
{
    private Request $request;

    public function __construct(
        private readonly string $archivDir,
        private readonly string $installConf
    )
    {
    }

    #[Route('/composer-event', name: 'composer_event')]
    public function composer_event(Request $request): void
    {
        $response = new StreamedResponse();
        $response->headers->set('X-Accel-Buffering', 'no');
        $response->headers->set('Content-Type', 'text/event-stream');
        $response->headers->set('Cache-Control', 'no-cache');
        $this->request = $request;
        $response->setCallback(function (): void {
            try {
                $last = '';
                $config = Yaml::parseFile($this->getParameter('installConf'));
                $archivDir = $config['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
                $log = $archivDir. 'install.log';
                $filesystem = new Filesystem();
                $lineCount = 0;
                if($filesystem->exists($log)) {
                    $lineCount = count(file($log));
                }

                $return = $this->get_composer_log($lineCount, $config);

                echo "event: composerLog\n";
                echo 'data: ' . json_encode($return);
                echo "\n\n";
            } catch (Exception $e) {
                $return = [
                    'code' => $e->getCode(),
                    'msg' => $e->getMessage()
                ];
                echo "event: errorLog\n";
                echo 'data: ' . json_encode($return);
                echo "\n\n";
            }


            flush();
            sleep(1);

            session_write_close();
            if (connection_aborted()) {
                //break;
            }
        });

        $response->send();
    }

    /**
     * @throws Exception
     */
    private function get_composer_log($newCount, $config): object
    {
        $response = new stdClass();
        $filesystem = new Filesystem();
        $response->status = false;

        $archivDir = $config['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
        $log = $archivDir. 'install.log';
        $installJson = $archivDir . 'install.json';
        $lineCount = 0;
        if($filesystem->exists($log)) {
            $lineCount = count(file($log));
        }

        if (!$filesystem->exists($installJson)) {
            $jsonArr = [
                'old' => 0,
                'new' => $newCount
            ];
            file_put_contents($installJson, json_encode($jsonArr));
        }
        $jsonArr = json_decode(file_get_contents($installJson), true);
        $jsonArr['old'] = $lineCount;
        $jsonArr['new'] = $newCount;
        file_put_contents($installJson, json_encode($jsonArr));
        $arr = [];
        if($filesystem->exists($log)) {
            if($this->file($log)) {
                $logLines = $this->tailWithSkip($log, 10);
                $arr = explode(PHP_EOL, $logLines);
                $response->log = $logLines;
                $response->lines = $arr;
                $response->status = true;
                return $response;
            }
        }

        //throw new Exception('log-file error (' . __LINE__ . ')', 1);
        file_put_contents($log, '');
        $response->count = $jsonArr;
        $response->lines = $arr;
        return $response;
        //throw new Exception('RegEx error (' . __LINE__ . ')', 1);
    }

    private function tailWithSkip($filepath, $lines = 1, $skip = 0, $adaptive = true): string
    {
        clearstatcache();
        $f = @fopen($filepath, "rb");
        if (@flock($f, LOCK_SH) === false) {
            return '';
        }
        if ($f === false) {
            return '';
        }
        if (!$adaptive) {
            $buffer = 4096;
        } else {
            $max = max($lines, $skip);
            $buffer = ($max < 2 ? 64 : ($max < 10 ? 512 : 4096));
        }
        // Jump to last character
        fseek($f, -1, SEEK_END);
        // Read it and adjust line number if necessary
        // (Otherwise the result would be wrong if file doesn't end with a blank line)
        if (fread($f, 1) == "\n") {
            if ($skip > 0) {
                $skip++;
                $lines--;
            }
        } else {
            $lines--;
        }
        // Start reading
        $output = '';
        $chunk = '';
        // While we would like more
        while (ftell($f) > 0 && $lines >= 0) {
            // Figure out how far back we should jump
            $seek = min(ftell($f), $buffer);
            // Do the jump (backwards, relative to where we are)
            fseek($f, -$seek, SEEK_CUR);
            // Read a chunk
            $chunk = fread($f, $seek);
            // Calculate chunk parameters
            $count = substr_count($chunk, "\n");
            $strlen = mb_strlen($chunk, '8bit');

            // Move the file pointer
            fseek($f, -$strlen, SEEK_CUR);
            if ($skip > 0) { // There are some lines to skip
                if ($skip > $count) {
                    $skip -= $count;
                    $chunk = '';
                } // Chunk contains less new line symbols than
                else {
                    $pos = 0;
                    while ($skip > 0) {
                        if ($pos > 0) {
                            $offset = $pos - $strlen - 1;
                        } // Calculate the offset - NEGATIVE position of last new line symbol
                        else {
                            $offset = 0;
                        } // First search (without offset)

                        $pos = strrpos($chunk, "\n", $offset); // Search for last (including offset) new line symbol
                        if ($pos !== false) {
                            $skip--;
                        } // Found new line symbol - skip the line
                        else {
                            break;
                        } // "else break;" - Protection against infinite loop (just in case)
                    }
                    $chunk = substr($chunk, 0, $pos); // Truncated chunk
                    $count = substr_count($chunk, "\n"); // Count new line symbols in truncated chunk
                }
            }

            if (strlen($chunk) > 0) {
                // Add chunk to the output
                $output = $chunk . $output;
                // Decrease our line counter
                $lines -= $count;
            }
        }
        // While we have too many lines
        // (Because of buffer size we might have read too many)
        while ($lines++ < 0) {
            // Find first newline and remove all text before that
            $output = substr($output, strpos($output, "\n") + 1);
        }
        // Close file and return
        @flock($f, LOCK_UN);
        fclose($f);
        return trim($output);
    }
}
