/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_holder_id` int(11) NOT NULL,
  `image_filename` varchar(255) DEFAULT NULL,
  `register_ip` varchar(255) DEFAULT NULL,
  `title` varchar(24) DEFAULT NULL,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `country` varchar(125) DEFAULT NULL,
  `street` varchar(125) DEFAULT NULL,
  `hnr` varchar(12) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `mobil` varchar(64) DEFAULT NULL,
  `notiz` varchar(255) DEFAULT NULL,
  `change_pw` tinyint(1) NOT NULL,
  `must_validated` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `voter` longtext NOT NULL COMMENT '(DC2Type:json)',
  `gravatar` varchar(24) DEFAULT 'mp',
  PRIMARY KEY (`id`),
  KEY `IDX_7D3656A4FC94BA8B` (`account_holder_id`),
  CONSTRAINT `FK_7D3656A4FC94BA8B` FOREIGN KEY (`account_holder_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `account` VALUES (1,1,NULL,'172.22.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'2024-06-03 22:40:30','[\"ACCOUNT_EDIT\",\"MANAGE_ACCOUNT\",\"ADD_ACCOUNT\",\"MANAGE_AUTHORISATION\",\"EDIT_ROLES\",\"ACCOUNT_EMAIL\",\"MANAGE_EMAIL\",\"SEND_EMAIL\",\"MANAGE_API\",\"EDIT_GRANTS\",\"MANAGE_SYSTEM_SETTINGS\",\"MANAGE_ACTIVITY\",\"MANAGE_EMAIL_SETTINGS\",\"MANAGE_REGISTRATION\",\"MANAGE_ACTIVATION\",\"MANAGE_APP_SETTINGS\",\"MANAGE_LOG\",\"MANAGE_OAUTH\",\"ACCOUNT_DELETE\",\"MANAGE_MEDIEN\",\"ACCOUNT_UPLOAD\",\"MEDIEN_CONVERTER\",\"MANAGE_BACKUP\",\"ADD_BACKUP\",\"MANAGE_PAGE\",\"MANAGE_PAGE_SEO\",\"MANAGE_PAGE_SITES\",\"MANAGE_PAGE_CATEGORY\",\"MANAGE_SITE_BUILDER\",\"MANAGE_BUILDER_SITES\",\"MANAGE_BUILDER_PLUGINS\",\"MANAGE_POST\",\"ADD_POST\",\"POST_CATEGORY_DESIGN\",\"POST_DESIGN\",\"POST_LOOP_DESIGN\",\"DELETE_POST\",\"DELETE_POST_CATEGORY\",\"MANAGE_GALLERY_SLIDER\",\"MEDIEN_SLIDER\",\"MEDIEN_CAROUSEL\",\"MEDIEN_GALLERY\",\"MANAGE_MENU\",\"ADD_MENU\",\"MANAGE_SCSS_COMPILER\",\"MANAGE_DESIGN\",\"MANAGE_FONTS\",\"DELETE_FONTS\",\"MANAGE_HEADER\",\"MANAGE_FOOTER\",\"MANAGE_TOOLS\",\"MANAGE_MAPS_PROTECTION\",\"MANAGE_FORMS\",\"ADD_FORMS\",\"DELETE_FORMS\",\"MANAGE_CONSUMER\",\"MANAGE_CUSTOM_FIELDS\"]','mp'),(2,2,NULL,'127.0.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'2024-06-03 22:40:30','[\"ACCOUNT_EDIT\",\"MANAGE_ACCOUNT\",\"ADD_ACCOUNT\",\"MANAGE_AUTHORISATION\",\"EDIT_ROLES\",\"ACCOUNT_EMAIL\",\"SEND_EMAIL\",\"MANAGE_API\",\"MANAGE_MEDIEN\",\"ACCOUNT_UPLOAD\",\"MANAGE_DESIGN\",\"MANAGE_FONTS\",\"MANAGE_TOOLS\",\"MANAGE_MAPS_PROTECTION\",\"MANAGE_FORMS\",\"ADD_FORMS\",\"DELETE_FORMS\",\"MANAGE_CUSTOM_FIELDS\"]','mp'),(3,3,NULL,'127.0.0.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'2024-06-03 22:40:31','[\"ACCOUNT_SHOW\",\"ACCOUNT_EDIT\",\"MANAGE_MEDIEN\",\"ACCOUNT_UPLOAD\"]','mp');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `account` with 3 row(s)
--

--
-- Table structure for table `app_fonts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_fonts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(128) NOT NULL,
  `is_woff` tinyint(1) NOT NULL,
  `is_woff2` tinyint(1) NOT NULL,
  `is_ttf` tinyint(1) NOT NULL,
  `local_name` longtext NOT NULL COMMENT '(DC2Type:json)',
  `font_info` longtext NOT NULL COMMENT '(DC2Type:json)',
  `font_data` longtext NOT NULL COMMENT '(DC2Type:json)',
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_fonts`
--

LOCK TABLES `app_fonts` WRITE;
/*!40000 ALTER TABLE `app_fonts` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `app_fonts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `app_fonts` with 0 row(s)
--

--
-- Table structure for table `app_maps`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  `designation` varchar(128) NOT NULL,
  `map_data` longtext NOT NULL COMMENT '(DC2Type:json)',
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_maps`
--

LOCK TABLES `app_maps` WRITE;
/*!40000 ALTER TABLE `app_maps` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `app_maps` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `app_maps` with 0 row(s)
--

--
-- Table structure for table `app_sites`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_category_id` int(11) DEFAULT NULL,
  `site_slug` varchar(255) NOT NULL,
  `route_name` varchar(255) DEFAULT NULL,
  `site_content` longtext DEFAULT NULL,
  `site_date` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `site_excerpt` longtext DEFAULT NULL,
  `site_status` varchar(64) NOT NULL DEFAULT 'publish',
  `comment_status` tinyint(1) NOT NULL,
  `site_type` varchar(64) NOT NULL,
  `site_img` varchar(255) DEFAULT NULL,
  `site_user` varchar(255) DEFAULT NULL,
  `site_password` varchar(255) DEFAULT NULL,
  `excerpt_limit` int(11) DEFAULT NULL,
  `extra_css` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `header` int(11) DEFAULT NULL,
  `footer` int(11) DEFAULT NULL,
  `builder_active` tinyint(1) NOT NULL,
  `custom` varchar(128) DEFAULT NULL,
  `form_builder` int(11) DEFAULT NULL,
  `siteSeo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6AD327AEA307269B` (`site_slug`),
  UNIQUE KEY `UNIQ_6AD327AEC4C079A6` (`siteSeo`),
  KEY `IDX_6AD327AEF968A252` (`site_category_id`),
  CONSTRAINT `FK_6AD327AEC4C079A6` FOREIGN KEY (`siteSeo`) REFERENCES `site_seo` (`id`),
  CONSTRAINT `FK_6AD327AEF968A252` FOREIGN KEY (`site_category_id`) REFERENCES `site_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_sites`
--

LOCK TABLES `app_sites` WRITE;
/*!40000 ALTER TABLE `app_sites` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `app_sites` VALUES (1,1,'','app_public_index',NULL,'2024-06-03 22:41:58',NULL,'publish',0,'page',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,NULL,NULL,1);
/*!40000 ALTER TABLE `app_sites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `app_sites` with 1 row(s)
--

--
-- Table structure for table `backups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `version` varchar(12) NOT NULL,
  `type` varchar(24) NOT NULL,
  `file_created` tinyint(1) NOT NULL,
  `archive_id` varchar(255) DEFAULT NULL,
  `status_msg` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `backups` with 0 row(s)
--

--
-- Table structure for table `emails_sent`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emails_sent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `abs_user` varchar(128) NOT NULL,
  `type` varchar(64) NOT NULL,
  `sent_from` varchar(128) NOT NULL,
  `sent_to` varchar(128) NOT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email_cc` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `email_bcc` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `if_show` tinyint(1) NOT NULL,
  `email_context` longtext NOT NULL COMMENT '(DC2Type:json)',
  `email_template` varchar(255) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `email_attachments` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails_sent`
--

LOCK TABLES `emails_sent` WRITE;
/*!40000 ALTER TABLE `emails_sent` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `emails_sent` VALUES (1,'email@jenswiecker.de','ds-email','email@jenswiecker.de','jens@wiecker.eu','Test','[]','[]',0,'{\"site_name\":\"RocketsApp\",\"content\":\"<p>Test E-Mail<\\/p>\"}','send-dashboard-email.html.twig','email@jenswiecker.de','[]','2024-06-03 22:43:27');
/*!40000 ALTER TABLE `emails_sent` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `emails_sent` with 1 row(s)
--

--
-- Table structure for table `forms`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) NOT NULL,
  `form_id` varchar(64) NOT NULL,
  `form` longtext NOT NULL COMMENT '(DC2Type:json)',
  `type` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `forms` with 0 row(s)
--

--
-- Table structure for table `form_builder`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_builder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` varchar(64) NOT NULL,
  `type` varchar(64) NOT NULL,
  `form` longtext NOT NULL COMMENT '(DC2Type:json)',
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E74BCF725FF69B7D` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_builder`
--

LOCK TABLES `form_builder` WRITE;
/*!40000 ALTER TABLE `form_builder` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `form_builder` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `form_builder` with 0 row(s)
--

--
-- Table structure for table `log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `message` longtext NOT NULL,
  `context` longtext NOT NULL COMMENT '(DC2Type:json)',
  `level` smallint(6) NOT NULL,
  `level_name` varchar(50) NOT NULL,
  `channel` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `formatted` longtext NOT NULL,
  `log_show` tinyint(1) NOT NULL,
  `extra` longtext NOT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`),
  KEY `IDX_8F3F68C5A76ED395` (`user_id`),
  CONSTRAINT `FK_8F3F68C5A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `log` with 0 row(s)
--

--
-- Table structure for table `media`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `original` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `size_data` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `type` varchar(24) NOT NULL,
  `attr` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `show_filemanager` int(11) NOT NULL,
  `mime` varchar(255) NOT NULL,
  `custom_css` varchar(255) DEFAULT NULL,
  `extension` varchar(255) NOT NULL,
  `labelling` longtext DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `exifData` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6A2CA10C37A2B0C4` (`exifData`),
  KEY `IDX_6A2CA10C12469DE2` (`category_id`),
  KEY `IDX_6A2CA10CA76ED395` (`user_id`),
  CONSTRAINT `FK_6A2CA10C12469DE2` FOREIGN KEY (`category_id`) REFERENCES `media_category` (`id`),
  CONSTRAINT `FK_6A2CA10C37A2B0C4` FOREIGN KEY (`exifData`) REFERENCES `media_exif` (`id`),
  CONSTRAINT `FK_6A2CA10CA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `media` with 0 row(s)
--

--
-- Table structure for table `media_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `designation` varchar(128) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `type` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_92D3773A76ED395` (`user_id`),
  CONSTRAINT `FK_92D3773A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_category`
--

LOCK TABLES `media_category` WRITE;
/*!40000 ALTER TABLE `media_category` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `media_category` with 0 row(s)
--

--
-- Table structure for table `media_exif`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_exif` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exif_file` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `exif_computed` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `exif_ifdo` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `exif_exif` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `exif_gps` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `gps_geo` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_exif`
--

LOCK TABLES `media_exif` WRITE;
/*!40000 ALTER TABLE `media_exif` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media_exif` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `media_exif` with 0 row(s)
--

--
-- Table structure for table `media_slider`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slider` longtext NOT NULL COMMENT '(DC2Type:json)',
  `designation` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_slider`
--

LOCK TABLES `media_slider` WRITE;
/*!40000 ALTER TABLE `media_slider` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media_slider` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `media_slider` with 0 row(s)
--

--
-- Table structure for table `menu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tree_root` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `menu_category_id` int(11) DEFAULT NULL,
  `title` varchar(64) NOT NULL,
  `description` longtext DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `css_class` varchar(255) DEFAULT NULL,
  `attr` varchar(255) DEFAULT NULL,
  `new_tab` tinyint(1) NOT NULL,
  `xfn` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `show_login` tinyint(1) NOT NULL,
  `show_not_login` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `lvl` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `original_title` varchar(255) DEFAULT NULL,
  `site` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7D053A93A977936C` (`tree_root`),
  KEY `IDX_7D053A93727ACA70` (`parent_id`),
  KEY `IDX_7D053A937ABA83AE` (`menu_category_id`),
  CONSTRAINT `FK_7D053A93727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_7D053A937ABA83AE` FOREIGN KEY (`menu_category_id`) REFERENCES `menu_category` (`id`),
  CONSTRAINT `FK_7D053A93A977936C` FOREIGN KEY (`tree_root`) REFERENCES `menu` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `menu` with 0 row(s)
--

--
-- Table structure for table `menu_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `menu_settings` longtext NOT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_category`
--

LOCK TABLES `menu_category` WRITE;
/*!40000 ALTER TABLE `menu_category` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `menu_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `menu_category` with 0 row(s)
--

--
-- Table structure for table `messenger_messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `messenger_messages` with 0 row(s)
--

--
-- Table structure for table `oauth2_access_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth2_access_token` (
  `identifier` char(80) NOT NULL,
  `client` varchar(32) NOT NULL,
  `expiry` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `user_identifier` varchar(128) DEFAULT NULL,
  `scopes` text DEFAULT NULL COMMENT '(DC2Type:oauth2_scope)',
  `revoked` tinyint(1) NOT NULL,
  PRIMARY KEY (`identifier`),
  KEY `IDX_454D9673C7440455` (`client`),
  CONSTRAINT `FK_454D9673C7440455` FOREIGN KEY (`client`) REFERENCES `oauth2_client` (`identifier`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2_access_token`
--

LOCK TABLES `oauth2_access_token` WRITE;
/*!40000 ALTER TABLE `oauth2_access_token` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `oauth2_access_token` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `oauth2_access_token` with 0 row(s)
--

--
-- Table structure for table `oauth2_authorization_code`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth2_authorization_code` (
  `identifier` char(80) NOT NULL,
  `client` varchar(32) NOT NULL,
  `expiry` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `user_identifier` varchar(128) DEFAULT NULL,
  `scopes` text DEFAULT NULL COMMENT '(DC2Type:oauth2_scope)',
  `revoked` tinyint(1) NOT NULL,
  PRIMARY KEY (`identifier`),
  KEY `IDX_509FEF5FC7440455` (`client`),
  CONSTRAINT `FK_509FEF5FC7440455` FOREIGN KEY (`client`) REFERENCES `oauth2_client` (`identifier`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2_authorization_code`
--

LOCK TABLES `oauth2_authorization_code` WRITE;
/*!40000 ALTER TABLE `oauth2_authorization_code` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `oauth2_authorization_code` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `oauth2_authorization_code` with 0 row(s)
--

--
-- Table structure for table `oauth2_client`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth2_client` (
  `identifier` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  `secret` varchar(128) DEFAULT NULL,
  `redirect_uris` text DEFAULT NULL COMMENT '(DC2Type:oauth2_redirect_uri)',
  `grants` text DEFAULT NULL COMMENT '(DC2Type:oauth2_grant)',
  `scopes` text DEFAULT NULL COMMENT '(DC2Type:oauth2_scope)',
  `active` tinyint(1) NOT NULL,
  `allow_plain_text_pkce` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2_client`
--

LOCK TABLES `oauth2_client` WRITE;
/*!40000 ALTER TABLE `oauth2_client` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `oauth2_client` VALUES ('44EMBWM8F927QRX0YSGT0B2KN4','App client','N8FRWJFG4DXXNTHVYHkS7YCURPV5pxnMwOZds2BVaN6eGCQSEhZ9BIWCFA1EczI3XQJPZMyHP','http://localhost:8080/callback','authorization_code refresh_token client_credentials','PROFILE MEDIA BLOCK_READ BLOCK_WRITE',1,0),('44FES2W8F927QSTMESGT0B2KN4','admin@app.de','SOFWISTjXEKmfN46AvNECAeZVb3PQQKO8MUpTdFBPYzEyqDRZgM7tsAuBPWJW9I51KLDLwFG2','http://localhost:8080/callback','authorization_code refresh_token client_credentials','PROFILE MEDIA BLOCK_READ BLOCK_WRITE',1,0),('44NZ4S48F927QRHF6SGT0B2KN4','App client','HCwPTGCSRhnbz123D4BpNMmFAXTKRDKAvXTuJ6gYP7XWZRWBIG8EEVMMFQ95sGyYHSWBILOZk','http://localhost:8080/callback','authorization_code refresh_token client_credentials','BLOCK_READ',1,0);
/*!40000 ALTER TABLE `oauth2_client` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `oauth2_client` with 3 row(s)
--

--
-- Table structure for table `oauth2_refresh_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth2_refresh_token` (
  `identifier` char(80) NOT NULL,
  `access_token` char(80) DEFAULT NULL,
  `expiry` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `revoked` tinyint(1) NOT NULL,
  PRIMARY KEY (`identifier`),
  KEY `IDX_4DD90732B6A2DD68` (`access_token`),
  CONSTRAINT `FK_4DD90732B6A2DD68` FOREIGN KEY (`access_token`) REFERENCES `oauth2_access_token` (`identifier`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2_refresh_token`
--

LOCK TABLES `oauth2_refresh_token` WRITE;
/*!40000 ALTER TABLE `oauth2_refresh_token` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `oauth2_refresh_token` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `oauth2_refresh_token` with 0 row(s)
--

--
-- Table structure for table `oauth2_user_consent`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth2_user_consent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `expires` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  `scopes` longtext DEFAULT NULL COMMENT '(DC2Type:simple_array)',
  `ip_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C8F05D0119EB6921` (`client_id`),
  KEY `IDX_C8F05D01A76ED395` (`user_id`),
  CONSTRAINT `FK_C8F05D0119EB6921` FOREIGN KEY (`client_id`) REFERENCES `oauth2_client` (`identifier`),
  CONSTRAINT `FK_C8F05D01A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth2_user_consent`
--

LOCK TABLES `oauth2_user_consent` WRITE;
/*!40000 ALTER TABLE `oauth2_user_consent` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `oauth2_user_consent` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `oauth2_user_consent` with 0 row(s)
--

--
-- Table structure for table `plugin_sections`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(64) NOT NULL,
  `type` varchar(28) NOT NULL,
  `plugin` longtext NOT NULL COMMENT '(DC2Type:json)',
  `handle` varchar(64) NOT NULL,
  `element_id` varchar(64) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_sections`
--

LOCK TABLES `plugin_sections` WRITE;
/*!40000 ALTER TABLE `plugin_sections` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `plugin_sections` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `plugin_sections` with 0 row(s)
--

--
-- Table structure for table `post_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `type` varchar(24) NOT NULL,
  `cat_img` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `category_design` int(11) DEFAULT NULL,
  `post_design` int(11) DEFAULT NULL,
  `post_loop` int(11) DEFAULT NULL,
  `category_header` int(11) DEFAULT NULL,
  `category_footer` int(11) DEFAULT NULL,
  `post_header` int(11) DEFAULT NULL,
  `post_footer` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_category`
--

LOCK TABLES `post_category` WRITE;
/*!40000 ALTER TABLE `post_category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `post_category` VALUES (1,'Allgemein','Allgemeine Kategorie',0,'first',NULL,'general',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-06-04 13:12:31'),(2,'Kategorie Zwei','',0,'category',NULL,'kategorie-zwei',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-06-04 13:16:19'),(3,'Kategorie Drei','',0,'category',NULL,'kategorie-drei',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-06-04 13:16:32');
/*!40000 ALTER TABLE `post_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `post_category` with 3 row(s)
--

--
-- Table structure for table `post_sites`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_category_id` int(11) DEFAULT NULL,
  `post_content` longtext DEFAULT NULL,
  `post_date` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `post_excerpt` longtext DEFAULT NULL,
  `comment_status` tinyint(1) NOT NULL,
  `site_type` varchar(24) NOT NULL,
  `site_img` varchar(255) DEFAULT NULL,
  `excerpt_limit` int(11) DEFAULT NULL,
  `extra_css` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `post_status` varchar(64) NOT NULL DEFAULT 'publish',
  `builder` int(11) DEFAULT NULL,
  `post_slug` varchar(255) DEFAULT NULL,
  `header` int(11) DEFAULT NULL,
  `footer` int(11) DEFAULT NULL,
  `post_gallery` longtext DEFAULT NULL COMMENT '(DC2Type:json)',
  `siteSeo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2B1B268CC4C079A6` (`siteSeo`),
  KEY `IDX_2B1B268CFE0617CD` (`post_category_id`),
  CONSTRAINT `FK_2B1B268CC4C079A6` FOREIGN KEY (`siteSeo`) REFERENCES `site_seo` (`id`),
  CONSTRAINT `FK_2B1B268CFE0617CD` FOREIGN KEY (`post_category_id`) REFERENCES `post_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_sites`
--

LOCK TABLES `post_sites` WRITE;
/*!40000 ALTER TABLE `post_sites` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `post_sites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `post_sites` with 0 row(s)
--

--
-- Table structure for table `rememberme_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rememberme_token` (
  `series` varchar(88) NOT NULL,
  `value` varchar(88) NOT NULL,
  `lastUsed` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `class` varchar(100) NOT NULL,
  `username` varchar(200) NOT NULL,
  PRIMARY KEY (`series`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rememberme_token`
--

LOCK TABLES `rememberme_token` WRITE;
/*!40000 ALTER TABLE `rememberme_token` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `rememberme_token` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `rememberme_token` with 0 row(s)
--

--
-- Table structure for table `reset_password_request`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reset_password_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `selector` varchar(20) NOT NULL,
  `hashed_token` varchar(100) NOT NULL,
  `requested_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `expires_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_7CE748AA76ED395` (`user_id`),
  CONSTRAINT `FK_7CE748AA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reset_password_request`
--

LOCK TABLES `reset_password_request` WRITE;
/*!40000 ALTER TABLE `reset_password_request` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `reset_password_request` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `reset_password_request` with 0 row(s)
--

--
-- Table structure for table `site_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `position` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  `cat_img` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_category`
--

LOCK TABLES `site_category` WRITE;
/*!40000 ALTER TABLE `site_category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `site_category` VALUES (1,'Allgemein','Allgemeine Kategorie',0,'first',NULL,'general','2024-06-03 22:41:58');
/*!40000 ALTER TABLE `site_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `site_category` with 1 row(s)
--

--
-- Table structure for table `site_seo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_content` longtext DEFAULT NULL,
  `no_index` tinyint(1) NOT NULL,
  `no_follow` tinyint(1) NOT NULL,
  `fb_active` tinyint(1) NOT NULL,
  `og_type` varchar(64) DEFAULT NULL,
  `og_title` varchar(255) DEFAULT NULL,
  `og_content` longtext DEFAULT NULL,
  `og_image` varchar(255) DEFAULT NULL,
  `x_active` tinyint(1) NOT NULL,
  `x_type` varchar(64) DEFAULT NULL,
  `x_site` varchar(64) DEFAULT NULL,
  `x_creator` varchar(64) DEFAULT NULL,
  `fb_app_id` varchar(255) DEFAULT NULL,
  `fb_admins` varchar(255) DEFAULT NULL,
  `title_prefix` varchar(64) DEFAULT NULL,
  `title_suffix` varchar(64) DEFAULT NULL,
  `title_separator` varchar(6) DEFAULT '–',
  `reading_time` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `last_update` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_seo`
--

LOCK TABLES `site_seo` WRITE;
/*!40000 ALTER TABLE `site_seo` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `site_seo` VALUES (1,'Startseite','RocketsApp Startseite',0,0,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-06-03 22:41:58','2024-06-03 22:41:58');
/*!40000 ALTER TABLE `site_seo` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `site_seo` with 1 row(s)
--

--
-- Table structure for table `system_settings`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) NOT NULL,
  `designation` varchar(64) NOT NULL,
  `app` longtext NOT NULL COMMENT '(DC2Type:json)',
  `email` longtext NOT NULL COMMENT '(DC2Type:json)',
  `log` longtext NOT NULL COMMENT '(DC2Type:json)',
  `oauth` longtext NOT NULL COMMENT '(DC2Type:json)',
  `register` longtext NOT NULL COMMENT '(DC2Type:json)',
  `design` longtext NOT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8CAF11478947610D` (`designation`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `system_settings` VALUES (1,'1.0.0','system','{\"version\":\"1.0.0\",\"db_version\":\"1.0.0\",\"site_name\":\"DevelopApp\",\"admin_email\":\"email@jenswiecker.de\",\"dashboard_logo\":\"\",\"login_logo\":\"\",\"signature_logo\":\"\",\"dashboard_logo_size\":50,\"upload_types\":\"jpg,jpeg,png,gif,svg,pdf,mp4,mp3,m4v,m4a,webp,arw\",\"login_logo_size\":250,\"signature_logo_size\":150,\"gmaps_active\":true,\"html_minimise\":true,\"export_vendor\":false,\"privacy_page_route\":\"\",\"imprint_page_route\":\"\",\"agb_page_route\":\"\",\"scss_by_login_active\":false,\"scss_cache_active\":false,\"scss_map_active\":false,\"scss_cache_dir\":\"scss_cache\",\"scss_map_output\":\"compressed\",\"scss_map_option\":\"map_inline\",\"scss_source_file\":\"public-style.scss\",\"scss_destination_file\":\"public-style.css\",\"default_admin_voter\":[{\"id\":\"665e2a3e855b9\",\"default\":1,\"section\":\"user\",\"label\":\"Profil bearbeiten\",\"role\":\"ACCOUNT_EDIT\"},{\"id\":\"665e2a3e855c2\",\"default\":1,\"section\":\"user\",\"label\":\"Benutzer verwalten\",\"role\":\"MANAGE_ACCOUNT\"},{\"id\":\"665e2a3e855c9\",\"default\":1,\"section\":\"user\",\"label\":\"neuen Benutzer hinzuf\\u00fcgen\",\"role\":\"ADD_ACCOUNT\"},{\"id\":\"665e2a3e855d1\",\"default\":1,\"section\":\"user\",\"label\":\"Berechtigungen-Verwalten\",\"role\":\"MANAGE_AUTHORISATION\"},{\"id\":\"665e2a3e855d8\",\"default\":1,\"section\":\"user\",\"label\":\"Benutzerrollen-Verwalten\",\"role\":\"EDIT_ROLES\"},{\"id\":\"665e2a3e855df\",\"default\":1,\"section\":\"email\",\"label\":\"E-Mail aktiv\",\"role\":\"ACCOUNT_EMAIL\"},{\"id\":\"665e2a3e855e6\",\"default\":0,\"section\":\"email\",\"label\":\"E-Mail-Verwalten\",\"role\":\"MANAGE_EMAIL\"},{\"id\":\"665e2a3e855ed\",\"default\":1,\"section\":\"email\",\"label\":\"E-Mail senden\",\"role\":\"SEND_EMAIL\"},{\"id\":\"665e2a3e855f4\",\"default\":1,\"section\":\"api\",\"label\":\"API-Verwalten\",\"role\":\"MANAGE_API\"},{\"id\":\"665e2a3e855fb\",\"default\":0,\"section\":\"api\",\"label\":\"API Berechtigungen-Verwalten\",\"role\":\"EDIT_GRANTS\"},{\"id\":\"665e2a3e85602\",\"default\":0,\"section\":\"log\",\"label\":\"System-Einstellungen Verwalten\",\"role\":\"MANAGE_SYSTEM_SETTINGS\"},{\"id\":\"665e2a3e85609\",\"default\":0,\"section\":\"log\",\"label\":\"Aktivit\\u00e4ten-Verwalten\",\"role\":\"MANAGE_ACTIVITY\"},{\"id\":\"665e2a3e85610\",\"default\":0,\"section\":\"log\",\"label\":\"E-Mail-System Verwalten\",\"role\":\"MANAGE_EMAIL_SETTINGS\"},{\"id\":\"665e2a3e85617\",\"default\":0,\"section\":\"log\",\"label\":\"Registrierung-Verwalten\",\"role\":\"MANAGE_REGISTRATION\"},{\"id\":\"665e2a3e8561d\",\"default\":0,\"section\":\"log\",\"label\":\"Aktivierung-Verwalten\",\"role\":\"MANAGE_ACTIVATION\"},{\"id\":\"665e2a3e85624\",\"default\":0,\"section\":\"log\",\"label\":\"APP-Settings Verwalten\",\"role\":\"MANAGE_APP_SETTINGS\"},{\"id\":\"665e2a3e8562b\",\"default\":0,\"section\":\"log\",\"label\":\"Log Verwalten\",\"role\":\"MANAGE_LOG\"},{\"id\":\"665e2a3e85631\",\"default\":0,\"section\":\"log\",\"label\":\"oAuth2 Verwalten\",\"role\":\"MANAGE_OAUTH\"},{\"id\":\"665e2a3e85638\",\"default\":0,\"section\":\"user\",\"label\":\"Account l\\u00f6schen\",\"role\":\"ACCOUNT_DELETE\"},{\"id\":\"665e2a3e8563f\",\"default\":1,\"section\":\"media\",\"label\":\"Mediathek\",\"role\":\"MANAGE_MEDIEN\"},{\"id\":\"665e2a3e85646\",\"default\":1,\"section\":\"media\",\"label\":\"Mediathek-Upload\",\"role\":\"ACCOUNT_UPLOAD\"},{\"id\":\"665e2a3e8564d\",\"default\":0,\"section\":\"media\",\"label\":\"Bildkonverter\",\"role\":\"MEDIEN_CONVERTER\"},{\"id\":\"665e2a3e85654\",\"default\":0,\"section\":\"backup\",\"label\":\"Backup Verwalten\",\"role\":\"MANAGE_BACKUP\"},{\"id\":\"665e2a3e8565a\",\"default\":0,\"section\":\"backup\",\"label\":\"Backup erstellen\",\"role\":\"ADD_BACKUP\"},{\"id\":\"665e2a3e85661\",\"default\":0,\"section\":\"page\",\"label\":\"Webseiten verwalten\",\"role\":\"MANAGE_PAGE\"},{\"id\":\"665e2a3e85668\",\"default\":0,\"section\":\"page\",\"label\":\"Seo verwalten\",\"role\":\"MANAGE_PAGE_SEO\"},{\"id\":\"665e2a3e8566f\",\"default\":0,\"section\":\"page\",\"label\":\"Seiten verwalten\",\"role\":\"MANAGE_PAGE_SITES\"},{\"id\":\"665e2a3e85675\",\"default\":0,\"section\":\"page\",\"label\":\"Seiten Kategorien Verwalten\",\"role\":\"MANAGE_PAGE_CATEGORY\"},{\"id\":\"665e2a3e8567c\",\"default\":0,\"section\":\"page\",\"label\":\"Page-Builder Verwalten\",\"role\":\"MANAGE_SITE_BUILDER\"},{\"id\":\"665e2a3e85683\",\"default\":0,\"section\":\"page\",\"label\":\"Page-Builder Layouts Verwalten\",\"role\":\"MANAGE_BUILDER_SITES\"},{\"id\":\"665e2a3e85689\",\"default\":0,\"section\":\"page\",\"label\":\"Page-Builder Plugins Verwalten\",\"role\":\"MANAGE_BUILDER_PLUGINS\"},{\"id\":\"665e2a3e85690\",\"default\":0,\"section\":\"posts\",\"label\":\"Beitr\\u00e4ge Verwalten\",\"role\":\"MANAGE_POST\"},{\"id\":\"665e2a3e85696\",\"default\":0,\"section\":\"posts\",\"label\":\"Beitr\\u00e4ge erstellen\",\"role\":\"ADD_POST\"},{\"id\":\"665e2a3e8569d\",\"default\":0,\"section\":\"posts\",\"label\":\"Kategorie Design\",\"role\":\"POST_CATEGORY_DESIGN\"},{\"id\":\"665e2a3e856a4\",\"default\":0,\"section\":\"posts\",\"label\":\"Beitrag Design\",\"role\":\"POST_DESIGN\"},{\"id\":\"665e2a3e856aa\",\"default\":0,\"section\":\"posts\",\"label\":\"Beitrags loop Design\",\"role\":\"POST_LOOP_DESIGN\"},{\"id\":\"665e2a3e856b9\",\"default\":0,\"section\":\"posts\",\"label\":\"Beitrag l\\u00f6schen\",\"role\":\"DELETE_POST\"},{\"id\":\"665e2a3e856c0\",\"default\":0,\"section\":\"posts\",\"label\":\"Kategorie l\\u00f6schen\",\"role\":\"DELETE_POST_CATEGORY\"},{\"id\":\"665e2a3e856c6\",\"default\":0,\"section\":\"tools\",\"label\":\"Galerie Verwalten\",\"role\":\"MANAGE_GALLERY_SLIDER\"},{\"id\":\"665e2a3e856cd\",\"default\":0,\"section\":\"tools\",\"label\":\"Medien Slider\",\"role\":\"MEDIEN_SLIDER\"},{\"id\":\"665e2a3e856d4\",\"default\":0,\"section\":\"tools\",\"label\":\"Medien Carousel\",\"role\":\"MEDIEN_CAROUSEL\"},{\"id\":\"665e2a3e856db\",\"default\":0,\"section\":\"tools\",\"label\":\"Galerie\",\"role\":\"MEDIEN_GALLERY\"},{\"id\":\"665e2a3e856e2\",\"default\":0,\"section\":\"menu\",\"label\":\"Men\\u00fc Verwalten\",\"role\":\"MANAGE_MENU\"},{\"id\":\"665e2a3e856e9\",\"default\":0,\"section\":\"menu\",\"label\":\"Men\\u00fc hinzuf\\u00fcgen\",\"role\":\"ADD_MENU\"},{\"id\":\"665e2a3e856ef\",\"default\":0,\"section\":\"log\",\"label\":\"SCSS Compiler Settings\",\"role\":\"MANAGE_SCSS_COMPILER\"},{\"id\":\"665e2a3e856f6\",\"default\":1,\"section\":\"design\",\"label\":\"Design Einstellungen\",\"role\":\"MANAGE_DESIGN\"},{\"id\":\"665e2a3e856fd\",\"default\":1,\"section\":\"design\",\"label\":\"Fonts verwalten\",\"role\":\"MANAGE_FONTS\"},{\"id\":\"665e2a3e85703\",\"default\":0,\"section\":\"design\",\"label\":\"Fonts l\\u00f6schen\",\"role\":\"DELETE_FONTS\"},{\"id\":\"665e2a3e8570b\",\"default\":0,\"section\":\"design\",\"label\":\"Header verwalten\",\"role\":\"MANAGE_HEADER\"},{\"id\":\"665e2a3e85711\",\"default\":0,\"section\":\"design\",\"label\":\"Footer verwalten\",\"role\":\"MANAGE_FOOTER\"},{\"id\":\"665e2a3e85718\",\"default\":1,\"section\":\"tools\",\"label\":\"Tools verwalten\",\"role\":\"MANAGE_TOOLS\"},{\"id\":\"665e2a3e8571f\",\"default\":1,\"section\":\"tools\",\"label\":\"Map Datenschutz verwalten\",\"role\":\"MANAGE_MAPS_PROTECTION\"},{\"id\":\"665e2a3e85726\",\"default\":1,\"section\":\"forms\",\"label\":\"Formulare Verwalten\",\"role\":\"MANAGE_FORMS\"},{\"id\":\"665e2a3e8572c\",\"default\":1,\"section\":\"forms\",\"label\":\"Formular erstellen\",\"role\":\"ADD_FORMS\"},{\"id\":\"665e2a3e85733\",\"default\":1,\"section\":\"forms\",\"label\":\"Formular l\\u00f6schen\",\"role\":\"DELETE_FORMS\"},{\"id\":\"665e2a3e85739\",\"default\":0,\"section\":\"log\",\"label\":\"Worker verwalten\",\"role\":\"MANAGE_CONSUMER\"},{\"id\":\"665e2a3e85740\",\"default\":1,\"section\":\"tools\",\"label\":\"Benutzerdefinierte Felder\",\"role\":\"MANAGE_CUSTOM_FIELDS\"}],\"default_user_voter\":[{\"id\":\"665e2a3e85749\",\"default\":1,\"section\":\"user\",\"label\":\"Profil anzeigen\",\"role\":\"ACCOUNT_SHOW\"},{\"id\":\"665e2a3e85750\",\"default\":1,\"section\":\"user\",\"label\":\"Profil bearbeiten\",\"role\":\"ACCOUNT_EDIT\"},{\"id\":\"665e2a3e85757\",\"default\":0,\"section\":\"user\",\"label\":\"Account l\\u00f6schen\",\"role\":\"ACCOUNT_DELETE\"},{\"id\":\"665e2a3e8575f\",\"default\":1,\"section\":\"media\",\"label\":\"Mediathek\",\"role\":\"MANAGE_MEDIEN\"},{\"id\":\"665e2a3e8576c\",\"default\":1,\"section\":\"media\",\"label\":\"Mediathek-Upload\",\"role\":\"ACCOUNT_UPLOAD\"}]}','{\"async_active\":true,\"email_save_active\":true,\"attachment_active\":true,\"reply_to\":\"jens@wiecker.eu\",\"attachment_max_count\":10,\"attachment_max_size\":5,\"forms\":{\"async_active\":true,\"email_save_active\":true,\"save_attachment\":true,\"abs_name\":\"\",\"abs_email\":\"noreply@wwdh.de\",\"reply_to\":\"\",\"email_template\":\"send-public-email.html.twig\"},\"abs_email\":\"noreply@wwdh.de\",\"abs_name\":\"Jens Wiecker\"}','{\"login\":false,\"login_error\":false,\"logout\":false,\"register\":false,\"forgot_password\":false,\"password_change\":false,\"account_activated\":false,\"account_deactivated\":false,\"account_deleted\":false,\"backup_created\":false,\"backup_deleted\":false,\"email_send\":false}','{\"jwks_kty\":\"RSA\",\"jwks_alg\":\"RS256\",\"jwks_use\":\"sig\",\"default_scope\":\"BLOCK_READ\",\"jwks_x5c\":\"\",\"jwks_x5t\":\"\"}','{\"show_forgotten_password\":true,\"registration_active\":false,\"registration_method\":1,\"send_notification\":false,\"send_after_validate\":false,\"email_notification\":\"\",\"show_company\":0,\"show_title\":0,\"show_name\":0,\"show_street\":0,\"show_city\":0,\"show_phone\":0,\"show_mobile\":0,\"leak_checker\":true}','{\"font_headline\":[{\"id\":\"h1\",\"label\":\"H1\",\"size\":40,\"size_sm\":28,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-weight\":\"500\",\"font-style\":\"\",\"line-height\":\"1.2\"},{\"id\":\"h2\",\"label\":\"H2\",\"size\":32,\"size_sm\":24,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-style\":\"\",\"font-weight\":\"500\",\"line-height\":\"1.2\"},{\"id\":\"h3\",\"label\":\"H3\",\"size\":28,\"size_sm\":22,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-style\":\"\",\"font-weight\":\"500\",\"line-height\":\"1.2\"},{\"id\":\"h4\",\"label\":\"H4\",\"size\":24,\"size_sm\":20,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-style\":\"\",\"font-weight\":\"500\",\"line-height\":\"1.2\"},{\"id\":\"h5\",\"label\":\"H5\",\"size\":20,\"size_sm\":18,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-style\":\"\",\"font-weight\":\"500\",\"line-height\":\"1.2\"},{\"id\":\"h6\",\"label\":\"H6\",\"size\":16,\"size_sm\":16,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"display\":false,\"font-family\":\"\",\"font-style\":\"\",\"font-weight\":\"500\",\"line-height\":\"1.2\"}],\"font\":[{\"id\":\"body\",\"label\":\"Body\",\"font-family\":\"\",\"font-style\":\"\",\"size\":16,\"size_sm\":16,\"uppercase\":false,\"color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":1},\"font-weight\":\"normal\",\"line-height\":\"1.5\"},{\"id\":\"menu\",\"label\":\"Men\\u00fc\",\"font-family\":\"\",\"font-style\":\"\",\"size\":16,\"size_sm\":16,\"uppercase\":false,\"color\":\"\",\"font-weight\":\"normal\",\"line-height\":\"1.5\"},{\"id\":\"button\",\"label\":\"Button\",\"font-family\":\"\",\"font-style\":\"\",\"size\":16,\"size_sm\":16,\"uppercase\":false,\"color\":\"\",\"font-weight\":\"normal\",\"line-height\":\"1.5\"}],\"color\":{\"menu_uppercase\":false,\"scroll_btn_active\":true,\"site_bg\":{\"r\":255,\"g\":255,\"b\":255,\"a\":1},\"nav_bg\":{\"r\":230,\"g\":230,\"b\":230,\"a\":0.8},\"footer_bg\":{\"r\":248,\"g\":249,\"b\":250,\"a\":1},\"footer_color\":{\"r\":33,\"g\":37,\"b\":41,\"a\":0.75},\"menu_btn_bg_color\":{\"r\":230,\"g\":230,\"b\":230,\"a\":0},\"menu_btn_color\":{\"r\":71,\"g\":71,\"b\":71,\"a\":1},\"menu_btn_active_bg\":{\"r\":230,\"g\":230,\"b\":230,\"a\":0},\"menu_btn_active_color\":{\"r\":60,\"g\":67,\"b\":74,\"a\":1},\"menu_btn_hover_bg\":{\"r\":230,\"g\":230,\"b\":230,\"a\":0},\"menu_btn_hover_color\":{\"r\":60,\"g\":67,\"b\":74,\"a\":1},\"dropdown_bg\":{\"r\":230,\"g\":230,\"b\":230,\"a\":1},\"menu_dropdown_bg\":{\"r\":230,\"g\":230,\"b\":230,\"a\":1},\"menu_dropdown_color\":{\"r\":71,\"g\":71,\"b\":71,\"a\":1},\"menu_dropdown_active_bg\":{\"r\":212,\"g\":212,\"b\":212,\"a\":1},\"menu_dropdown_active_color\":{\"r\":60,\"g\":67,\"b\":74,\"a\":1},\"menu_dropdown_hover_bg\":{\"r\":237,\"g\":237,\"b\":237,\"a\":1},\"menu_dropdown_hover_color\":{\"r\":60,\"g\":67,\"b\":74,\"a\":1},\"link_color\":{\"r\":0,\"g\":98,\"b\":189,\"a\":1},\"link_aktiv_color\":{\"r\":0,\"g\":68,\"b\":128,\"a\":1},\"link_hover_color\":{\"r\":0,\"g\":124,\"b\":232,\"a\":1},\"scroll_btn_bg\":{\"r\":0,\"g\":98,\"b\":189,\"a\":1},\"scroll_btn_color\":{\"r\":255,\"g\":255,\"b\":255,\"a\":1}}}');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `system_settings` with 1 row(s)
--

--
-- Table structure for table `user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` binary(16) NOT NULL COMMENT '(DC2Type:uuid)',
  `email` varchar(180) NOT NULL,
  `roles` longtext NOT NULL COMMENT '(DC2Type:json)',
  `password` varchar(255) NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `user` VALUES (1,0x847517CA21E911EF8E83D98680B14EA4,'email@jenswiecker.de','[\"ROLE_ADMIN\",\"ROLE_SUPER_ADMIN\"]','$2y$13$3/dHVm5ep5t2VzGoeCpTKuUGVuM5ymeODAWpN83zqsCTQZ5cLkCXy',1,NULL),(2,0x847BB22E21E911EF9D51D98680B14EA4,'admin@app.de','[\"ROLE_ADMIN\"]','$2y$13$.3UHq6NKeMgAf8VCKCcSaOykRwDGuSwEAAjwkOMlOLqgJNf.F9jy.',1,NULL),(3,0x84AFC99221E911EF88BCD98680B14EA4,'user@app.de','[]','$2y$13$4Aa/hnJ./TbZJgkYhs3/ceb5.OtmNx1ak7nOkmx1ERGJ3T7sbZq1C',1,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `user` with 3 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Tue, 04 Jun 2024 19:25:10 +0200
