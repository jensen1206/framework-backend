<?php


use App\InstallHelper\Helper;
use Defuse\Crypto\Exception\EnvironmentIsBrokenException;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use stdClass;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Path;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Messenger\Exception\HandlerFailedException;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Yaml\Yaml;
use Defuse\Crypto\Key;
use Symfony\Component\Console\Messenger\RunCommandMessage;
use Symfony\Component\Messenger\MessageBusInterface;
use Doctrine\DBAL\Exception\ConnectionException;
use ZipArchive;

class MainControllerSave extends AbstractController
{
    private string $phpDataVersion;

    public function __construct(
        private readonly EntityManagerInterface $em,
        private readonly MessageBusInterface    $bus,
        private readonly Helper                 $helper
    )
    {


    }

    #[Route('/', name: 'app_main')]
    public function index(Request $request): Response
    {

        if (version_compare(PHP_VERSION, $request->server->get('PHP_MIN'), '<')) {
            $this->addFlash('install_error', sprintf('Installation nicht möglich. Ihre PHP-Version %s ist nicht kompatibel. Es wird eine PHP-Version %s benötigt.', PHP_VERSION, $request->server->get('PHP_MIN')));
            return $this->render('main/index.html.twig', [
                'title' => 'Datenbank Settings',
            ]);
        }
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/index.html.twig', [
                'title' => 'Datenbank Settings',
                'data' => []
            ]);
        }
        //dd($conf);

        $btnPressed = $request->get('install_app') !== null;
        if ($request->getMethod() === 'POST' && $btnPressed) {
            $input = $request->request;
            $db_name = $this->helper->trim_string(filter_var($input->get('db_name'), FILTER_UNSAFE_RAW));
            $db_user = $this->helper->trim_string(filter_var($input->get('db_user'), FILTER_UNSAFE_RAW));
            $db_pw = filter_var($input->get('db_pw'), FILTER_UNSAFE_RAW);
            $db_host = $this->helper->trim_string(filter_var($input->get('db_host'), FILTER_UNSAFE_RAW));
            $db_charset = $this->helper->trim_string(filter_var($input->get('db_charset'), FILTER_UNSAFE_RAW));
            $db_server = $this->helper->trim_string(filter_var($input->get('db_server'), FILTER_UNSAFE_RAW));
            if (!$db_name || !$db_user || !$db_pw || !$db_host) {
                $this->addFlash('input_error', 'bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/index.html.twig', [
                    'title' => 'Datenbank Settings',
                    'data' => $conf->record
                ]);
            }
            if (!$db_charset) {
                $db_charset = 'utf8mb4';
            }
            if (!$db_server) {
                $db_server = 'mariadb-10.3.36';
            }
            $dsn = sprintf('mysql://%s:%s@%s:3306/%s?serverVersion=%s&charset=%s', $db_user, $db_pw, $db_host, $db_name, $db_server, $db_charset);
            $envJson = $conf->record;

            $envJsonDb = $envJson['database'];
            $json = $envJson['envJson'];

            $envJsonDb['user'] = $db_user;
            $envJsonDb['password'] = $db_pw;
            $envJsonDb['host'] = $db_host;
            $envJsonDb['dbname'] = $db_name;
            $envJsonDb['charset'] = $db_charset;
            $envJsonDb['serverVersion'] = $db_server;
            $json['DATABASE_URL'] = $dsn;

            $envJson['database'] = $envJsonDb;
            $envJson['envJson'] = $json;

            $yaml = Yaml::dump($envJson, 6);

            file_put_contents($this->getParameter('installConf'), $yaml);
            $env = $this->getParameter('projectDir') . DIRECTORY_SEPARATOR . '.env';
            file_put_contents($env, '');
            foreach ($json as $key => $val) {
                $put = $key . '=' . $val . "\r\n";
                file_put_contents($env, $put, FILE_APPEND | LOCK_EX);
            }


            return $this->redirect($this->generateUrl('app_settings'));

        }

        //dd($phpVersion);
        return $this->render('main/index.html.twig', [
            'title' => 'Datenbank Settings',
            'data' => $conf->record
        ]);
    }

    #[Route('/settings', name: 'app_settings')]
    public function settings(Request $request): Response
    {
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/step-two.html.twig', [
                'title' => 'Datenbank Settings',
                'data' => []
            ]);
        }

        if (!$this->helper->database_is_installed()) {
            $this->addFlash('input_error', 'Es konnte <b>keine Verbindung</b> zu Ihrer Datenbank hergestellt werden.');
            return $this->redirect($this->generateUrl('app_main'));
        }

        $ref = basename($request->headers->get('referer'));

        if ($request->getMethod() === 'GET' && $ref != 'public') {
            return $this->redirect($this->generateUrl('app_main'));
        }

        $btnPressed = $request->get('install_two_app') !== null;
        if ($request->getMethod() === 'POST' && $btnPressed) {
            $input = $request->request;
            $site_name = $this->helper->pregWhitespace(filter_var($input->get('site_name'), FILTER_UNSAFE_RAW));
            $install_path = $this->helper->trim_string(filter_var($input->get('install_path'), FILTER_UNSAFE_RAW));
            $install_url = $this->helper->trim_string(filter_var($input->get('install_url'), FILTER_VALIDATE_URL));
            $email_user = $this->helper->trim_string(filter_var($input->get('email_user'), FILTER_UNSAFE_RAW));
            $email_host = $this->helper->trim_string(filter_var($input->get('email_host'), FILTER_UNSAFE_RAW));
            $email_pw = $this->helper->trim_string(filter_var($input->get('email_pw'), FILTER_UNSAFE_RAW));
            $email_port = $this->helper->trim_string(filter_var($input->get('email_port'), FILTER_VALIDATE_INT));
            $jsonConf = $conf->record;
            $emailDsn = $jsonConf['email_dsn'];
            $envJson = $jsonConf['envJson'];

            if (!$install_path || !$install_url) {
                $this->addFlash('input_error', 'bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/step-two.html.twig', [
                    'title' => 'Installation Einstellungen',
                    'data' => $conf->record
                ]);
            }

            if (str_ends_with($install_url, '/')) {
                $install_url = preg_replace('%/$%', '', $install_url);
            }
            if (str_ends_with($install_path, '/')) {
                $install_path = preg_replace('%/$%', '', $install_path);
            }
            if (!is_dir($install_path)) {
                $this->addFlash('input_error', 'bitte überprüfen Sie Ihre Eingaben');
                return $this->render('main/step-two.html.twig', [
                    'title' => 'Installation Einstellungen',
                    'data' => $conf->record
                ]);
            }

            $jsonConf['install_dir'] = $install_path;
            $envJson['SITE_BASE_URL'] = $install_url;
            if ($site_name) {
                $envJson['APP_SITE_NAME'] = $site_name;
            }
            if ($email_user) {
                $emailDsn['username'] = $email_user;
            }
            if ($email_host) {
                $emailDsn['host'] = $email_host;
            }
            if ($email_pw) {
                $emailDsn['pw'] = $email_pw;
            }
            if ($email_port) {
                $emailDsn['port'] = $email_port;
            }

            $dsn = sprintf('smtp://%s:%s@%s:%d', $emailDsn['username'], $emailDsn['pw'], $emailDsn['host'], $emailDsn['port']);
            $envJson['MAILER_DSN'] = $dsn;
            $jsonConf['email_dsn'] = $emailDsn;
            $jsonConf['envJson'] = $envJson;

            $yaml = Yaml::dump($jsonConf, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);

            $env = $this->getParameter('projectDir') . DIRECTORY_SEPARATOR . '.env';
            file_put_contents($env, '');
            foreach ($envJson as $key => $val) {
                $put = $key . '=' . $val . "\r\n";
                file_put_contents($env, $put, FILE_APPEND | LOCK_EX);
            }

            $sqlFile = $this->getParameter('archivDir') . $jsonConf['json_file']['sql_file'];
            if (!is_file($sqlFile) || !$this->helper->database_is_installed()) {
                $this->addFlash('input_error', 'Datenbank SQL-File nicht gefunden.');
                return $this->redirect($this->generateUrl('app_main'));
            }
            $conn = $this->em->getConnection();
            $sql = "SELECT app FROM system_settings WHERE designation = ?";
            $result = '';
            try {
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(1, "system");
                $resultSet = $stmt->executeQuery();
                $result = $resultSet->fetchOne();

            } catch (Exception $e) {
                //$this->addFlash('input_error', 'Datenbank konnte nicht erstellt werden. (cmd exec) - '.$e->getMessage());
                $phpData = $jsonConf['envJson']['PHP_VERSION_DATA'];
                $dir = $this->getParameter('projectDir') . DIRECTORY_SEPARATOR;
                $cmd = sprintf('%s %sbin/console dbal:run-sql "$(cat %s)"', $phpData, $dir, $sqlFile);
                // $this->bus->dispatch(new RunCommandMessage($cmd));
                exec($cmd);
            }

            try {
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(1, "system");
                $resultSet = $stmt->executeQuery();
                $result = $resultSet->fetchOne();
                if (!$result) {
                    $this->addFlash('input_error', 'Datenbank konnte nicht erstellt werden.');
                    return $this->redirect($this->generateUrl('app_main'));
                }

            } catch (Exception) {
                $this->addFlash('input_error', 'Datenbank konnte nicht erstellt werden.');
                return $this->redirect($this->generateUrl('app_main'));
            }
            $result = json_decode($result, true);

            $installData = [
                'version' => $result['version'],
                'title' => $result['site_name'],
                'admin' => $result['admin_email']
            ];

            $jsonConf['install_data'] = $installData;
            $yaml = Yaml::dump($jsonConf, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);

            return $this->redirect($this->generateUrl('app_install'));
        }

        return $this->render('main/step-two.html.twig', [
            'title' => 'Installation Einstellungen',
            'data' => $conf->record
        ]);
    }

    #[Route('/app-install', name: 'app_install')]
    public function app_install(Request $request): Response
    {
        $conf = $this->get_archive_data($request);
        if (!$conf->status) {
            $this->addFlash('install_error', $conf->msg);
            return $this->render('main/install.html.twig', [
                'title' => 'Archiv Installieren',
                'data' => []
            ]);
        }
        $conf = $conf->record;
        $ref = basename($request->headers->get('referer'));

        if ($request->getMethod() === 'GET' && $ref != 'settings') {
            return $this->redirect($this->generateUrl('app_main'));
        }

        $btnPressed = $request->get('install') !== null;
        if ($request->getMethod() === 'POST' && $btnPressed) {
            if (!is_dir($conf['install_dir'])) {
                $this->addFlash('install_error', 'Installation Verzeichnis nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }

            $archiveDir = $this->getParameter('archivDir');
            $zipFile = $archiveDir . $conf['json_file']['id'] . '.zip';
            if (!is_file($zipFile)) {
                $this->addFlash('install_error', 'Installation Zip-Archiv nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }

            $archivDir = $conf['install_dir'] . DIRECTORY_SEPARATOR . 'archiv' . DIRECTORY_SEPARATOR;
            if (!is_dir($archivDir)) {
                $zip = new ZipArchive();
                if ($zip->open($zipFile) === TRUE) {
                    $zip->extractTo($conf['install_dir'] . DIRECTORY_SEPARATOR);
                    $zip->close();
                } else {
                    $this->addFlash('install_error', 'Fehler beim entpacken der Archiv Datei!');
                    return $this->redirect($this->generateUrl('app_main'));
                }
            }

            $archivConf = $archivDir . '.env';
            if (!is_file($archivConf)) {
                $this->addFlash('install_error', 'Archiv Konfiguration nicht gefunden!');
                return $this->redirect($this->generateUrl('app_main'));
            }
            file_put_contents($archivConf, '');
            foreach ($conf['envJson'] as $key => $val) {
                $put = $key . '=' . $val . "\r\n";
                file_put_contents($archivConf, $put, FILE_APPEND | LOCK_EX);
            }

            return $this->redirect($this->generateUrl('app_install_finale'));
        }

        return $this->render('main/install.html.twig', [
            'title' => 'Archiv Installieren',
            'data' => $conf
        ]);
    }

    #[Route('/finale', name: 'app_install_finale')]
    public function app_install_finale(Request $request): Response
    {
        $ref = basename($request->headers->get('referer'));
        if ($request->getMethod() === 'GET' && $ref != 'app-install') {
            return $this->redirect($this->generateUrl('app_main'));
        }

        $btnPressed = $request->get('remove_install') !== null;
        if ($request->getMethod() === 'POST' && $btnPressed) {
            $conf = $this->get_archive_data($request);
            if (!$conf->status) {
                $this->addFlash('install_error', $conf->msg);
                return $this->render('main/install.html.twig', [
                    'title' => 'Archiv Installieren',
                    'data' => []
                ]);
            }
            $conf = $conf->record;
            $path = $conf['install_dir'] . DIRECTORY_SEPARATOR;

            $filesystem = new Filesystem();
            try {
                $filesystem->mirror($path . 'archiv', $path);
            } catch (IOExceptionInterface $e) {
                $this->addFlash('install_error', 'Archiv konnte nicht Kopiert werden! (' . $e->getMessage() . ')');
                return $this->redirect($this->generateUrl('app_main'));
            }
            $page = $conf['envJson']['SITE_BASE_URL'];
            try {
                $filesystem->remove($path . 'archiv');
            } catch (IOExceptionInterface $e) {
                $this->addFlash('install_error', 'Archiv konnte nicht gelöscht werden! ('.$e->getMessage().')');
                return $this->redirect($this->generateUrl('app_main'));
            }
            $newSitePublic = $path . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR;
            try {
                $this->bus->dispatch(new RunCommandMessage('cache:clear'));
            } catch (HandlerFailedException $exception) {
                $this->addFlash('install_error', $exception->getMessage());
                return $this->redirect($this->generateUrl('app_main'));
            }
            return $this->redirect($page);
        }
        //
        return $this->render('bibliotheken-installieren.html.twig', [
            'title' => 'Installation abschließen',
            'data' => []
        ]);
    }

    public function get_archive_data($request): object
    {
        $return = new stdClass();
        $return->status = false;
        if (!is_file($this->getParameter('installConf'))) {
            $installJson = '';
            $installSql = '';
            $installZip = '';
            $archivScanned = array_diff(scandir($this->getParameter('archivDir')), array('..', '.'));
            foreach ($archivScanned as $tmp) {
                $pathInfo = pathinfo($this->getParameter('archivDir') . $tmp);
                if ($pathInfo['extension'] == 'json' && $pathInfo['filename'] != 'env') {
                    $installJson = $tmp;
                    continue;
                }

                if ($pathInfo['extension'] == 'sql') {
                    $installSql = $tmp;
                    continue;
                }
                if ($pathInfo['extension'] == 'zip') {
                    $installZip = $tmp;
                    continue;
                }

            }
            $installJson = json_decode(file_get_contents($this->getParameter('archivDir') . $installJson), true);
            $envJson = json_decode(file_get_contents($this->getParameter('archivDir') . 'env.json'), true);
            if (!$installJson) {
                $return->msg = 'Json File kann nicht gefunden werden.';
                return $return;
            }

            if (!$installSql) {
                $return->msg = 'SQL File kann nicht gefunden werden.';
                return $return;
            }
            if (!$installZip) {
                $return->msg = 'Archiv File kann nicht gefunden werden.';
                return $return;
            }

            $zipSize = $this->helper->fileSizeConvert($this->helper->get_file_size($this->getParameter('archivDir') . $installZip));
            $sqlSize = $this->helper->fileSizeConvert($this->helper->get_file_size($this->getParameter('archivDir') . $installSql));
            $created_date = date('d.m.Y H:i:s', $installJson['file_time']);

            $re = '~\d.*~';
            preg_match($re, PHP_DATADIR, $matches);
            $matches ? $v = $matches[0] : $v = '';
            $phpDataVersion = 'php' . $v;
            $conn = $this->em->getConnection('doctrine');
            $dsn = $conn->getParams();

            $installUrl = $request->getSchemeAndHttpHost();
            $appSecret = md5(time());

            try {
                $key = Key::createNewRandomKey();
                $key = $key->saveToAsciiSafeString();
            } catch (EnvironmentIsBrokenException $e) {
                $return->msg = $e->getMessage();
                return $return;
            }

            $regDsn = '%(.+?)://(.*):(.+)@(.+)?:(\d{1,5})%';
            preg_match($regDsn, $request->server->get('MAILER_DSN'), $matches);
            $email = [
                'type' => $matches[1] ?? null,
                'username' => $matches[2] ?? null,
                'pw' => $matches[3] ?? null,
                'host' => $matches[4] ?? null,
                'port' => $matches[5] ?? null
            ];

            $platform = sprintf('%s %s', php_uname('s'), php_uname('r'));
            $envJson['vars']['PHP_VERSION_DATA'] = $phpDataVersion;
            $envJson['vars']['APP_SECRET'] = $appSecret;
            $envJson['vars']['SITE_BASE_URL'] = $installUrl;
            $config = [
                'install_dir' => dirname($this->getParameter('projectDir')),
                'json_file' => $installJson,
                'archiv_size' => $zipSize,
                'platform' => $platform,
                'php_version' => PHP_VERSION,
                'sql_size' => $sqlSize,
                'defuse_key' => $key,
                'created' => $created_date,
                'database' => $dsn,
                'envJson' => $envJson['vars'],
                'email_dsn' => $email,
            ];

            $yaml = Yaml::dump($config, 6);
            file_put_contents($this->getParameter('installConf'), $yaml);
            $return->status = true;
            $return->record = $config;
            return $return;
        }

        $config = Yaml::parseFile($this->getParameter('installConf'));
        $return->status = true;
        $return->record = $config;
        return $return;

    }
}
